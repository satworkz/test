﻿
UPDATE "TradAcc#__a" set "ActualLegalNameSource" = 0;
UPDATE "TradAcc#__a" set "NDAApplicableSource" = 0;
UPDATE "TradAcc#__a" set "CptyAccNoSource" = 0;
UPDATE "TradAcc#__a" set "CptyTypeSource" = 0;
UPDATE "TradAcc#__a" set "FinInstTypeSource" = 0;
UPDATE "TradAcc#__a" set "CptyBICSource" = 0;
UPDATE "TradAcc#__a" set "SciLeidSource" = 0;

/
