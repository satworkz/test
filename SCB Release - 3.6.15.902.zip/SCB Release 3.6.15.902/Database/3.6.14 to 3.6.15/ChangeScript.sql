﻿ALTER TABLE "TradAcc" ADD "ActualLegalName" NVARCHAR2 (100);
ALTER TABLE "TradAcc" ADD "ActualLegalNameSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "NDAApplicable" NUMBER (1, 0);
ALTER TABLE "TradAcc" ADD "NDAApplicableSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "CptyAccNo" NVARCHAR2 (40);
ALTER TABLE "TradAcc" ADD "CptyAccNoSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "CptyType" NVARCHAR2 (10);
ALTER TABLE "TradAcc" ADD "CptyTypeSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "FinInstType" NVARCHAR2 (10);
ALTER TABLE "TradAcc" ADD "FinInstTypeSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "CptyBIC" NVARCHAR2 (40);
ALTER TABLE "TradAcc" ADD "CptyBICSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;
ALTER TABLE "TradAcc" ADD "SciLeid" NVARCHAR2 (40);
ALTER TABLE "TradAcc" ADD "SciLeidSource" NUMBER (5, 0) DEFAULT 0 NOT NULL;


ALTER TABLE "TradAcc#__a" ADD "ActualLegalName" NVARCHAR2 (100);
ALTER TABLE "TradAcc#__a" ADD "ActualLegalNameSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "NDAApplicable" NUMBER (1, 0);
ALTER TABLE "TradAcc#__a" ADD "NDAApplicableSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "CptyAccNo" NVARCHAR2 (40);
ALTER TABLE "TradAcc#__a" ADD "CptyAccNoSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "CptyType" NVARCHAR2 (10);
ALTER TABLE "TradAcc#__a" ADD "CptyTypeSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "FinInstType" NVARCHAR2 (10);
ALTER TABLE "TradAcc#__a" ADD "FinInstTypeSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "CptyBIC" NVARCHAR2 (40);
ALTER TABLE "TradAcc#__a" ADD "CptyBICSource" NUMBER (5, 0);
ALTER TABLE "TradAcc#__a" ADD "SciLeid" NVARCHAR2 (40);
ALTER TABLE "TradAcc#__a" ADD "SciLeidSource" NUMBER (5, 0);
/

create or replace procedure "TradAcc_A"
(
 c0 out sys_refcursor , 
 c1 out sys_refcursor , 
 c2 out sys_refcursor , 
 c3 out sys_refcursor , 
 c4 out sys_refcursor , 
 c5 out sys_refcursor , 
 c6 out sys_refcursor , 
 c7 out sys_refcursor , 
 c8 out sys_refcursor , 
 c9 out sys_refcursor , 
 c10 out sys_refcursor , 
 c11 out sys_refcursor , 
 c12 out sys_refcursor , 
 c13 out sys_refcursor , 
 c14 out sys_refcursor , 
 c15 out sys_refcursor , 
 c16 out sys_refcursor )
is
begin
 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc" t1 join "AssObj" t2 on (t2."oid" = t1."oid");
 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters" t1 order by t1."docOrder" asc ;
 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets" t1 order by t1."docOrder" asc ;
 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets" t1 order by t1."docOrder" asc ;
 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis" t1 order by t1."docOrder" asc ;
 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships" t1 order by t1."docOrder" asc ;
 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i" t1 join "TradAcc" root on (t1."oid" = root."oid");
 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core" t1 join "TradAcc" root on (t1."oid" = root."oid");
 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change" t1 join "TradAcc" root on (t1."oid" = root."oid");
 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers" t1 join "TradAcc" root on (t1."oid" = root."oid") order by t1."docOrder" asc ;
end;
/
create or replace procedure "TradAcc_T"
(
 c0 out sys_refcursor , 
 c1 out sys_refcursor , 
 c2 out sys_refcursor , 
 c3 out sys_refcursor , 
 c4 out sys_refcursor , 
 c5 out sys_refcursor , 
 c6 out sys_refcursor , 
 c7 out sys_refcursor , 
 c8 out sys_refcursor , 
 c9 out sys_refcursor , 
 c10 out sys_refcursor , 
 c11 out sys_refcursor , 
 c12 out sys_refcursor , 
 c13 out sys_refcursor , 
 c14 out sys_refcursor , 
 c15 out sys_refcursor , 
 c16 out sys_refcursor )
is
begin
 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc" t1 join "AssObj" t2 on (t2."oid" = t1."oid") join "__t" t on (t1."oid" = t."oid");
 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i" t1 join "__t" t on (t1."oid" = t."oid");
 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core" t1 join "__t" t on (t1."oid" = t."oid");
 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change" t1 join "__t" t on (t1."oid" = t."oid");
 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers" t1 join "__t" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
end;
/
create or replace procedure "TradAcc_TO"
(
 c0 out sys_refcursor , 
 c1 out sys_refcursor , 
 c2 out sys_refcursor , 
 c3 out sys_refcursor , 
 c4 out sys_refcursor , 
 c5 out sys_refcursor , 
 c6 out sys_refcursor , 
 c7 out sys_refcursor , 
 c8 out sys_refcursor , 
 c9 out sys_refcursor , 
 c10 out sys_refcursor , 
 c11 out sys_refcursor , 
 c12 out sys_refcursor , 
 c13 out sys_refcursor , 
 c14 out sys_refcursor , 
 c15 out sys_refcursor , 
 c16 out sys_refcursor )
is
begin
 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc" t1 join "AssObj" t2 on (t2."oid" = t1."oid") join "__to" t on (t1."oid" = t."oid") order by t."id" asc ;
 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i" t1 join "__to" t on (t1."oid" = t."oid");
 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core" t1 join "__to" t on (t1."oid" = t."oid");
 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change" t1 join "__to" t on (t1."oid" = t."oid");
 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers" t1 join "__to" t on (t1."oid" = t."oid") order by t1."docOrder" asc ;
end;
/
create or replace procedure "TradAcc_O"
(
oid RAW, 
 c0 out sys_refcursor , 
 c1 out sys_refcursor , 
 c2 out sys_refcursor , 
 c3 out sys_refcursor , 
 c4 out sys_refcursor , 
 c5 out sys_refcursor , 
 c6 out sys_refcursor , 
 c7 out sys_refcursor , 
 c8 out sys_refcursor , 
 c9 out sys_refcursor , 
 c10 out sys_refcursor , 
 c11 out sys_refcursor , 
 c12 out sys_refcursor , 
 c13 out sys_refcursor , 
 c14 out sys_refcursor , 
 c15 out sys_refcursor , 
 c16 out sys_refcursor )
is
begin
 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc" t1 join "AssObj" t2 on (t2."oid" = t1."oid") where (t1."oid" = oid);
 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters" t1 where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets" t1 where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets" t1 where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis" t1 where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships" t1 where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid);
 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid);
 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid);
 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers" t1 join "TradAcc" root on (t1."oid" = root."oid") where (t1."oid" = oid) order by t1."docOrder" asc ;
end;
/
create or replace procedure "TradAcc_AU"
(
oid RAW, 
version NUMBER)
is
begin
insert into "TradAcc#__a"("__version", "__action", "oid", "Counterparty", "IsSkeletonAccount", "AccountNetOrgCode", "AccountNetOrgCodeSource", "AccountNetAccountCode", "AccountNetAccountCodeSource", "LocalAcronym", "AlertAcronym", "AlertAcronymSource", "AlertAccessCode", "AlertAccessCodeSource", "SciLeid", "SciLeidSource", "ShortName", "ShortNameSource", "LongName", "LongNameSource", "LongName1", "LongName1Source", "FullName", "FullNameSource", "RiskCountry", "RiskCountrySource", "Nationality", "NationalitySource", "CustInternalAcNo", "CustInternalAcNoSource", "InstitutionName", "InstitutionNameSource", "InstitutionBic", "InstitutionBicSource", "TaxExempt", "TaxExemptSource", "TaxWithhold", "TaxWithholdSource", "CharityAccountRef", "CharityAccountRefSource", "TaxID", "TaxIDSource", "ClsCustomType", "AlertTrustedSrc", "AlertTrustedSrcSource", "SegmentCode", "SegmentCodeSource", "Address", "AddressSource", "City", "CitySource", "ActualLegalName", "ActualLegalNameSource", "NDAApplicable", "NDAApplicableSource", "CptyAccNo", "CptyAccNoSource", "CptyType", "CptyTypeSource", "FinInstType", "FinInstTypeSource", "CptyBIC", "CptyBICSource") select version, 1, t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc" t1 where (t1."oid" = oid);
end;
/
create or replace procedure "TradAcc_AS"
(
oid RAW, 
version NUMBER, 
 c0 out sys_refcursor , 
 c1 out sys_refcursor , 
 c2 out sys_refcursor , 
 c3 out sys_refcursor , 
 c4 out sys_refcursor , 
 c5 out sys_refcursor , 
 c6 out sys_refcursor , 
 c7 out sys_refcursor , 
 c8 out sys_refcursor , 
 c9 out sys_refcursor , 
 c10 out sys_refcursor , 
 c11 out sys_refcursor , 
 c12 out sys_refcursor , 
 c13 out sys_refcursor , 
 c14 out sys_refcursor , 
 c15 out sys_refcursor , 
 c16 out sys_refcursor )
is
maxVersion1  NUMBER (10, 0)
;
maxVersion2  NUMBER (10, 0)
;
found boolean := false;
begin
for x in (select  *  from "AssObj#__i#__a" t where (((t."oid" = oid) and (t."__version" = version)) and (t."__action" <> 2))) loop
found := true;
exit;
end loop;
if (found = true)
then
BEGIN
select max(t1."__version") into maxVersion1 from "TradAcc#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version));
exception
when NO_DATA_FOUND then
maxVersion1 := null;
END ;

BEGIN
select max(t2."__version") into maxVersion2 from "AssObj#__a" t2 where ((t2."oid" = oid) and (t2."__version" <= version));
exception
when NO_DATA_FOUND then
maxVersion2 := null;
END ;

 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc#__a" t1 join "AssObj#__a" t2 on (t2."oid" = t1."oid") where ((((t1."oid" = oid) and (t1."__version" = maxVersion1)) and (t1."__action" <> 2)) and ((t2."__version" = maxVersion2) and (t2."__action" <> 2)));

 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "TradAcc#MarketFilters#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "TradAcc#MktFilterSets#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "TradAcc#AvMarkets#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "TradAcc#RemovedSsis#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "TradAcc#Relationships#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

BEGIN
select max(t1."__version") into maxVersion1 from "AssObj#__i#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version));
exception
when NO_DATA_FOUND then
maxVersion1 := null;
END ;

 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i#__a" t1 where (((t1."oid" = oid) and (t1."__version" = maxVersion1)) and (t1."__action" <> 2));

 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#__acl#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

BEGIN
select max(t1."__version") into maxVersion1 from "AssObj#Core#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version));
exception
when NO_DATA_FOUND then
maxVersion1 := null;
END ;

 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core#__a" t1 where (((t1."oid" = oid) and (t1."__version" = maxVersion1)) and (t1."__action" <> 2));

BEGIN
select max(t1."__version") into maxVersion1 from "AssObj#Change#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version));
exception
when NO_DATA_FOUND then
maxVersion1 := null;
END ;

 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change#__a" t1 where (((t1."oid" = oid) and (t1."__version" = maxVersion1)) and (t1."__action" <> 2));

 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#SystemCodes#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#Notes#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#Docs#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#ValFail#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#ValFail#RelObj#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#LatestEditors#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers#__a" t1 join (select t1."eid", max(t1."__version") as "version" from "AssObj#LatestReviewers#__a" t1 where ((t1."oid" = oid) and (t1."__version" <= version)) group by t1."eid") ta on ((t1."eid" = ta."eid") and (t1."__version" = ta."version")) where ((t1."oid" = oid) and (t1."__action" <> 2)) order by t1."docOrder" asc ;

else
 open c0 for select t2."oid", t2."ChangeState", t2."StableChangeState", t2."StableChangeVersion", t2."Action", t2."LastEditorType", t2."DocumentsSource", t1."oid", t1."Counterparty", t1."IsSkeletonAccount", t1."AccountNetOrgCode", t1."AccountNetOrgCodeSource", t1."AccountNetAccountCode", t1."AccountNetAccountCodeSource", t1."LocalAcronym", t1."AlertAcronym", t1."AlertAcronymSource", t1."AlertAccessCode", t1."AlertAccessCodeSource", t1."SciLeid", t1."SciLeidSource", t1."ShortName", t1."ShortNameSource", t1."LongName", t1."LongNameSource", t1."LongName1", t1."LongName1Source", t1."FullName", t1."FullNameSource", t1."RiskCountry", t1."RiskCountrySource", t1."Nationality", t1."NationalitySource", t1."CustInternalAcNo", t1."CustInternalAcNoSource", t1."InstitutionName", t1."InstitutionNameSource", t1."InstitutionBic", t1."InstitutionBicSource", t1."TaxExempt", t1."TaxExemptSource", t1."TaxWithhold", t1."TaxWithholdSource", t1."CharityAccountRef", t1."CharityAccountRefSource", t1."TaxID", t1."TaxIDSource", t1."ClsCustomType", t1."AlertTrustedSrc", t1."AlertTrustedSrcSource", t1."SegmentCode", t1."SegmentCodeSource", t1."Address", t1."AddressSource", t1."City", t1."CitySource", t1."ActualLegalName", t1."ActualLegalNameSource", t1."NDAApplicable", t1."NDAApplicableSource", t1."CptyAccNo", t1."CptyAccNoSource", t1."CptyType", t1."CptyTypeSource", t1."FinInstType", t1."FinInstTypeSource", t1."CptyBIC", t1."CptyBICSource" from "TradAcc#__a" t1 join "AssObj#__a" t2 on (t2."oid" = t1."oid") where (0 = 1);

 open c1 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."Effect" from "TradAcc#MarketFilters#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c2 for select t1."oid", t1."eid", t1."docOrder", t1."MarketFilterSets" from "TradAcc#MktFilterSets#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c3 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#AvMarkets#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c4 for select t1."oid", t1."eid", t1."docOrder", t1."Country", t1."Security", t1."Method", t1."AlertIndex", t1."AccountNetModelName" from "TradAcc#RemovedSsis#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c5 for select t1."oid", t1."eid", t1."docOrder", t1."Status", t1."StatusSource", t1."InternalOrganisation", t1."InternalOrganisationSource" from "TradAcc#Relationships#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c6 for select t1."oid", t1."creationDate", t1."lastModifiedDate", t1."lastModifiedGuid", t1."creatorRef", t1."lastEditorRef", t1."version" from "AssObj#__i#__a" t1 where (0 = 1);

 open c7 for select t1."oid", t1."eid", t1."docOrder", t1."operation", t1."permissionType", t1."id", t1."role", t1."group", t1."authenticationType" from "AssObj#__acl#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c8 for select t1."oid", t1."ConcreteType", t1."LocalId", t1."LocalIdSource", t1."DataSource", t1."EffectiveDate", t1."EffectiveDateSource", t1."ClosingDate", t1."ClosingDateSource", t1."DataStatus", t1."OriginatingAssassinObject", t1."DataUpdateAction", t1."EffectiveTime", t1."EffectiveTimeSource", t1."EffectiveTimeZone", t1."EffectiveTimeZoneSource", t1."DataStatusSource", t1."FutureEffectiveParent", t1."UltimateFutureEffectiveParent", t1."EffectiveDateType", t1."EffectiveDateTypeSource", t1."OriginalDataSrc", t1."OriginalDataSrcSource" from "AssObj#Core#__a" t1 where (0 = 1);

 open c9 for select t1."oid", t1."LastApprovedVersion", t1."LatestReviewTime", t1."ChangeRequester", t1."ChangeRequestTime", t1."ChangeRequestType", t1."Priority", t1."UrgentReview", t1."OriginalDataSourceVersion", t1."CreateFutureEffectiveClones" from "AssObj#Change#__a" t1 where (0 = 1);

 open c10 for select t1."oid", t1."eid", t1."docOrder", t1."SystemCodeType", t1."SystemCodeTypeSource", t1."Value", t1."ValueSource", t1."ValueStatus", t1."ValueStatusSource" from "AssObj#SystemCodes#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c11 for select t1."oid", t1."eid", t1."docOrder", t1."Author", t1."DateTimeCreated", t1."Content", t1."ContentSource" from "AssObj#Notes#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c12 for select t1."oid", t1."eid", t1."docOrder", t1."Documents" from "AssObj#Docs#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c13 for select t1."oid", t1."eid", t1."docOrder", t1."Reason", t1."ValidationRule", t1."ChildEid", t1."AlternativeProperty", t1."FailureType" from "AssObj#ValFail#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c14 for select t1."oid", t1."eid", t1."peid", t1."docOrder", t1."RelatedObjects" from "AssObj#ValFail#RelObj#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c15 for select t1."oid", t1."eid", t1."docOrder", t1."LatestEditors" from "AssObj#LatestEditors#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

 open c16 for select t1."oid", t1."eid", t1."docOrder", t1."LatestReviewers" from "AssObj#LatestReviewers#__a" t1 where (0 = 1) order by t1."docOrder" asc ;

end if
;
end;
/

create or replace procedure "cspXMLObjectAnalysis"
(
  objoid raw,
  xmlObjectString out clob
)
IS
begin
 declare
 xml xmltype;

 coreObjcount integer;

 coreaObjcount integer;

 xmlObjectString2 varchar2(2000);

 datetime varchar(200);

 -- Summary Table Cursors
 cursor cur_sum_header is SELECT
 XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
			WHERE (table_name =  'AssObj#__a'  AND column_name IN ('__version', 'StableChangeVersion', 'LastApprovedVersion',
                             'ChangeState', 'StableChangeState', 'Action', 'lastModifiedDate',
                             'LastEditorType', 'Username', 'oid'))
               OR (table_name =  'AssObj#__i#__a'  AND column_name IN ('lastModifiedDate'))
               OR (table_name =  'AssObj#Change#__a'  AND column_name IN ('LastApprovedVersion'))
               OR (table_name =  'user'  AND column_name IN ('userName'));

 cursor cur_sum_data is  select
 XMLELEMENT("row", XMLAttributes( a."__version" as "__version",
                                  a."StableChangeVersion" as "StableChangeVersion",
                                  aoc."LastApprovedVersion" as "LastApprovedVersion",
                                  cs."EnumText" as "ChangeState",
                                  scs."EnumText" as "StableChangeState",
                                  act."EnumText" as "Action",
                                  aia."lastModifiedDate", ed."EnumText" as "LastEditorType",
                                  u."userName" "userName",
                                  a."oid" as "oid"))
 from "AssObj#__a" a
	  join "AssObj#__i#__a" aia on a."oid" = aia."oid" and a."__version" = aia."__version"
	  left join "AssObj#Change#__a" aoc on a."oid" = aoc."oid" and a."__version" = aoc."__version"
	  join "USER" u on u."oid" = aia."lastEditorRef"
	  left join "EnumLookup" cs on cs."EnumValue" = a."ChangeState" and cs."TypeName"='ChangeState'
	  left join "EnumLookup" scs on scs."EnumValue" = a."StableChangeState" and scs."TypeName"='ChangeState'
	  left join "EnumLookup" act on act."EnumValue" = a."Action" and act."TypeName"='ChangeAction'
	  left join "EnumLookup" ed on ed."EnumValue" = a."LastEditorType" and ed."TypeName"='Editor'
 where a."oid" = objoid
 order by a."__version";

 -- SSI Alert Messages Cursors
 cursor cur_ssi_alert_header is SELECT
 XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
            WHERE (table_name =  'AlertMsg#Alt'  AND column_name IN ('Acronym', 'Access_code', 'Description'))
               OR (table_name =  'AlertMsg#Alt#Sec'  AND column_name IN ('Country', 'Security', 'Method', 'Changes', 'Alert_id'))
               OR (table_name =  'AlertMsg'  AND column_name IN ('State', 'TimeStamp', 'SupersededBy', 'ProcessingStart', 'ProcessingEnd', 'TimesNumberExecuted'));


 cursor cur_ssi_alert_data is select
 XMLELEMENT("row", XMLAttributes( ama."Acronym" as "Acronym", ama."Access_code" as "Access_code", 
                                  ama."Description" as "Description", 
                                  s."Country" as "Country", s."Security" as "Security", s."Method" as "Method", 
                                  s."Priority" as "Priority", 
                                  s."Changes" as "Changes", 
                                  s."Alert_id" as "Alert_id", 
                                  am."State" as "State", 
                                  am."TimeStamp" as "TimeStamp", 
                                  am."SupersededBy" as "SupersededBy", 
                                  am."ProcessingStart" as "ProcessingStart", 
                                  am."ProcessingEnd" as "ProcessingEnd", 
                                  am."TimesNumberExecuted" as "TimesNumberExecuted" ))
from "SSI" ssi
join "TradAcc" ta on ta."oid"=ssi."TradingAccount"
join "AlertMsg#Alt" ama on ama."Acronym"=ta."AlertAcronym" and ama."Access_code"=ta."AlertAccessCode"
join "AlertMsg" am on am."oid" = ama."oid"
join "AlertMsg#Alt#Sec" s on ama."oid"=s."oid" and 
s."Country"=(select "AlertAbbreviation" from "Country" where "oid"=ssi."Country") and
s."Security"=(select "AlertAbbreviation" from "Security" where "oid"=ssi."Security") and
s."Method"=(select "AlertAbbreviation" from "Method" where "oid"=ssi."SettlementMethod")
where ssi."oid"= objoid;

 -- TA Alert Messages Table Cursors
 cursor cur_ta_alert_header is SELECT
 XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
            WHERE (table_name =  'AlertMsg#Alt'  AND column_name IN ('Acronym', 'Access_code', 'Description'))
               OR (table_name =  'AlertMsg#Alt#Sec'  AND column_name IN ('Country', 'Security', 'Method', 'Changes', 'Alert_id'))
               OR (table_name =  'AlertMsg'  AND column_name IN ('State', 'TimeStamp', 'SupersededBy', 'ProcessingStart', 'ProcessingEnd', 'TimesNumberExecuted'));


 cursor cur_ta_alert_data is select
 XMLELEMENT("row", XMLAttributes( ama."Acronym" as "Acronym", ama."Access_code" as "Access_code", 
                                  ama."Description" as "Description", 
                                  s."Country" as "Country", s."Security" as "Security", s."Method" as "Method", 
                                  s."Priority" as "Priority", 
                                  s."Changes" as "Changes", 
                                  s."Alert_id" as "Alert_id", 
                                  am."State" as "State", 
                                  am."TimeStamp" as "TimeStamp", 
                                  am."SupersededBy" as "SupersededBy", 
                                  am."ProcessingStart" as "ProcessingStart", 
                                  am."ProcessingEnd" as "ProcessingEnd", 
                                  am."TimesNumberExecuted" as "TimesNumberExecuted" ))
from "TradAcc" ta
join "AlertMsg#Alt" ama on ama."Acronym"=ta."AlertAcronym" and ama."Access_code"=ta."AlertAccessCode"
join "AlertMsg" am on am."oid" = ama."oid"
join "AlertMsg#Alt#Sec" s on ama."oid"=s."oid" 
where ta."oid"=objoid;



 -- AssObj Table Cursors
 cursor cur_assobj_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj') order by column_id;

 cursor cur_assobj_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid",
                                                        "ChangeState",
                                                        "StableChangeState",
                                                        "Action",
                                                        "LastEditorType",
                                                        "DocumentsSource"
                                                        )) from "AssObj" where "oid"=objoid;


 -- AssObjt#__i Table Cursors
 cursor cur_assobj#i_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#__i') order by column_id;

 cursor cur_assobj#i_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid",
                                                        "creationDate",
                                                        "lastModifiedDate",
                                                        "lastModifiedGuid",
                                                        "creatorRef",
                                                        "lastEditorRef",
                                                        "version"
                                                        )) from "AssObj#__i" where "oid"=objoid;

 -- AssObj#__i#__a Table Cursors
 cursor cur_assobj#i#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#__i#__a') order by column_id;

 cursor cur_assobj#i#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "creationDate"	,
                                                        "lastModifiedDate"	,
                                                        "lastModifiedGuid"	,
                                                        "creatorRef"	,
                                                        "lastEditorRef"	,
                                                        "version"
                                                        )) from "AssObj#__i#__a" where "oid"=objoid order by "__version";


 -- AssObj#__a Table Cursors
 cursor cur_assobj#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#__a') order by column_id;

 cursor cur_assobj#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "ChangeState"	,
                                                        "StableChangeState"	,
                                                        "StableChangeVersion"	,
                                                        "Action"	,
                                                        "LastEditorType"	,
                                                        "DocumentsSource"
                                                        )) from "AssObj#__a" where "oid"=objoid order by "__version";


 -- AssObj#Change Table Cursors
 cursor cur_assobjchange_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Change') order by column_id;

 cursor cur_assobjchange_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "LastApprovedVersion"	,
                                                        "LatestReviewTime"	,
                                                        "ChangeRequester"	,
                                                        "ChangeRequestTime"	,
                                                        "ChangeRequestType"	,
                                                        "Priority"	,
                                                        "UrgentReview"	,
                                                        "OriginalDataSourceVersion"	,
                                                        "CreateFutureEffectiveClones"
                                                        )) from "AssObj#Change" where "oid"=objoid;


 -- AssObj#Change#__a Table Cursors
 cursor cur_assobjchange#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Change#__a') order by column_id;

 cursor cur_assobjchange#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "Priority"	,
                                                        "UrgentReview"	,
                                                        "OriginalDataSourceVersion"	,
                                                        "CreateFutureEffectiveClones"	,
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "LastApprovedVersion"	,
                                                        "LatestReviewTime"	,
                                                        "ChangeRequester"	,
                                                        "ChangeRequestTime"	,
                                                        "ChangeRequestType"
                                                        )) from "AssObj#Change#__a" where "oid"=objoid order by "__version";


 -- AssObj#Core Table Cursors
 cursor cur_assobjcore_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Core') order by column_id;

 cursor cur_assobjcore_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "ConcreteType"	,
                                                        "LocalId"	,
                                                        "LocalIdSource"	,
                                                        "DataSource"	,
                                                        "EffectiveDate"	,
                                                        "EffectiveDateSource"	,
                                                        "EffectiveTime"	,
                                                        "EffectiveTimeSource"	,
                                                        "EffectiveTimeZone"	,
                                                        "EffectiveTimeZoneSource"	,
                                                        "ClosingDate"	,
                                                        "ClosingDateSource"	,
                                                        "DataStatus"	,
                                                        "DataStatusSource"	,
                                                        "OriginatingAssassinObject"	,
                                                        "DataUpdateAction"	,
                                                        "FutureEffectiveParent"	,
                                                        "UltimateFutureEffectiveParent"	,
                                                        "EffectiveDateType"	,
                                                        "EffectiveDateTypeSource"	,
                                                        "OriginalDataSrc"	,
                                                        "OriginalDataSrcSource"
                                                        )) from "AssObj#Core" where "oid"=objoid;


 -- AssObj#Core#__a Table Cursors
 cursor cur_assobjcore#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Core#__a') order by column_id;

 cursor cur_assobjcore#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "ConcreteType"	,
                                                        "LocalId"	,
                                                        "LocalIdSource"	,
                                                        "DataSource"	,
                                                        "EffectiveDate"	,
                                                        "EffectiveDateSource"	,
                                                        "EffectiveTime"	,
                                                        "EffectiveTimeSource"	,
                                                        "EffectiveTimeZone"	,
                                                        "EffectiveTimeZoneSource"	,
                                                        "ClosingDate"	,
                                                        "ClosingDateSource"	,
                                                        "DataStatus"	,
                                                        "DataStatusSource"	,
                                                        "OriginatingAssassinObject"	,
                                                        "DataUpdateAction"	,
                                                        "FutureEffectiveParent"	,
                                                        "UltimateFutureEffectiveParent"	,
                                                        "EffectiveDateType"	,
                                                        "EffectiveDateTypeSource"	,
                                                        "OriginalDataSrc"	,
                                                        "OriginalDataSrcSource"
                                                        )) from "AssObj#Core#__a" where "oid"=objoid order by "__version";


 -- AssObj#LatestEditors Table Cursors
 cursor cur_assobj#le_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#LatestEditors') order by column_id;

 cursor cur_assobj#le_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "LatestEditors"
                                                        )) from "AssObj#LatestEditors" where "oid"=objoid;


 -- AssObj#LatestEditors#__a Table Cursors
 cursor cur_assobj#le#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#LatestEditors#__a') order by column_id;

 cursor cur_assobj#le#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "LatestEditors"
                                                        )) from "AssObj#LatestEditors#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- AssObj#ValFail Table Cursors
 cursor cur_assobj#valfail_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#ValFail') order by column_id;

 cursor cur_assobj#valfail_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Reason"	,
                                                        "ValidationRule"	,
                                                        "ChildEid"	,
                                                        "AlternativeProperty"	,
                                                        "FailureType"
                                                        )) from "AssObj#ValFail" where "oid"=objoid;


 -- AssObj#ValFail#__a Table Cursors
 cursor cur_assobj#valfail#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#ValFail#__a') order by column_id;

 cursor cur_assobj#valfail#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                       "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Reason"	,
                                                        "ValidationRule"	,
                                                        "ChildEid"	,
                                                        "AlternativeProperty"	,
                                                        "FailureType"
                                                        )) from "AssObj#ValFail#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- AssObj#ValFail#RelObj Table Cursors
 cursor cur_assobj#valf#relo_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#ValFail#RelObj') order by column_id;

 cursor cur_assobj#valf#relo_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "peid"	,
                                                        "docOrder"	,
                                                        "RelatedObjects"
                                                        )) from "AssObj#ValFail#RelObj" where "oid"=objoid;


 -- AssObj#ValFail##RelObj__a Table Cursors
 cursor cur_assobj#valf#relo#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#ValFail#RelObj#__a') order by column_id;

 cursor cur_assobj#valf#relo#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "peid"	,
                                                        "docOrder"	,
                                                        "RelatedObjects"
                                                        )) from "AssObj#ValFail#RelObj#__a" where "oid"=objoid order by "__version";


 -- AssObj#LatestReviewers Table Cursors
 cursor cur_assobj#lr_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#LatestReviewers') order by column_id;

 cursor cur_assobj#lr_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "LatestReviewers"
                                                        )) from "AssObj#LatestReviewers" where "oid"=objoid;


 -- AssObj#LatestReviewers#__a Table Cursors
 cursor cur_assobj#lr#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#LatestReviewers#__a') order by column_id;

 cursor cur_assobj#lr#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "LatestReviewers"
                                                        )) from "AssObj#LatestReviewers#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- AssObj#Notes Table Cursors
 cursor cur_assobj#notes_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Notes') order by column_id;

 cursor cur_assobj#notes_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Author"	,
                                                        "DateTimeCreated"	,
                                                        "Content"	,
                                                        "ContentSource"
                                                        )) from "AssObj#Notes" where "oid"=objoid;


 -- AssObj#Notes#__a Table Cursors
 cursor cur_assobj#notes#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#Notes#__a') order by column_id;

 cursor cur_assobj#notes#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Author"	,
                                                        "DateTimeCreated"	,
                                                        "Content"	,
                                                        "ContentSource"
                                                        )) from "AssObj#Notes#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- AssObj#SystemCodes Table Cursors
 cursor cur_assobj#syscodes_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#SystemCodes') order by column_id;

 cursor cur_assobj#syscodes_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "SystemCodeType"	,
                                                        "SystemCodeTypeSource"	,
                                                        "Value"	,
                                                        "ValueSource"	,
                                                        "ValueStatus"	,
                                                        "ValueStatusSource"
                                                        )) from "AssObj#SystemCodes" where "oid"=objoid;


 -- AssObj#SystemCodes#__a Table Cursors
 cursor cur_assobj#syscodes#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#SystemCodes#__a') order by column_id;

 cursor cur_assobj#syscodes#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "SystemCodeType"	,
                                                        "SystemCodeTypeSource"	,
                                                        "Value"	,
                                                        "ValueSource"	,
                                                        "ValueStatus"	,
                                                        "ValueStatusSource"
                                                        )) from "AssObj#SystemCodes#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- AssObjt#__acl Table Cursors
 cursor cur_assobj#acl_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#__acl') order by column_id;

 cursor cur_assobj#acl_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "operation"	,
                                                        "permissionType"	,
                                                        "id"	,
                                                        "role"	,
                                                        "group"	,
                                                        "authenticationType"
                                                        )) from "AssObj#__acl" where "oid"=objoid;

 -- AssObj#__acl#__a Table Cursors
 cursor cur_assobj#acl#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'AssObj#__acl#__a') order by column_id;

 cursor cur_assobj#acl#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "operation"	,
                                                        "permissionType"	,
                                                        "id"	,
                                                        "role"	,
                                                        "group"	,
                                                        "authenticationType"
                                                        )) from "AssObj#__acl#__a" where "oid"=objoid  order by "__version", "docOrder" asc;


 -- SSI Table Cursors
 cursor cur_ssi_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SSI') order by column_id;

 cursor cur_ssi_data is select XMLELEMENT("row", XMLAttributes(
                                                       "ClassOfAccountSource"	,
                                                        "SettContact"	,
                                                        "SettContactSource"	,
                                                        "SettPhone"	,
                                                        "SettPhoneSource"	,
                                                        "SpecialInstruction1"	,
                                                        "SpecialInstruction1Source"	,
                                                        "SpecialInstruction2"	,
                                                        "SpecialInstruction2Source"	,
                                                        "AlertRelationship"	,
                                                        "AlertRelationshipSource"	,
                                                        "oid"	,
                                                        "TradingAccount"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "Security"	,
                                                        "SecuritySource"	,
                                                        "SettlementMethod"	,
                                                        "SettlementMethodSource"	,
                                                        "AlertIndex"	,
                                                        "Currency"	,
                                                        "CurrencySource"	,
                                                        "AltCurrency"	,
                                                        "AltCurrencySource"	,
                                                        "DefaultSsi"	,
                                                        "DefaultSsiSource"	,
                                                        "TermsOfDelivery"	,
                                                        "TermsOfDeliverySource"	,
                                                        "SettlementType"	,
                                                        "SettlementTypeSource"	,
                                                        "ClassOfAccount",
                                                        "ConfirmationMethod",
                                                        "ConfirmationMethodSource",
                                                        "AddCustodianToMT304Tag57",
                                                        "AddCustodianToMT304Tag57Source",
                                                        "BranchId",
                                                        "BranchIdSource",
                                                        "SettlementCode",
                                                        "SettlementCodeSource",
                                                        "Charges",
                                                        "ChargesSource",
                                                        "CmsAccount",
                                                        "CmsAccountSource",
                                                        "AebAccount",
                                                        "AebAccountSource",
                                                        "FiscAccount",
                                                        "FiscAccountSource",
                                                        "FinCopy",
                                                        "FinCopySource",
                                                        "CmsAccountNumber",
                                                        "CmsAccountNumberSource",
                                                        "SenderToReceiver1",
                                                        "SenderToReceiver1Source",
                                                        "SenderToReceiver2",
                                                        "SenderToReceiver2Source",
                                                        "SenderToReceiver3",
                                                        "SenderToReceiver3Source",
                                                        "SenderToReceiver4",
                                                        "SenderToReceiver4Source",
                                                        "SenderToReceiver5",
                                                        "SenderToReceiver5Source",
                                                        "SenderToReceiver6",
                                                        "SenderToReceiver6Source",
                                                        "SwiftType",
                                                        "SwiftTypeSource",
                                                        "DebitCredit",
                                                        "DebitCreditSource",
                                                        "PayDetails1",
                                                        "PayDetails1Source",
                                                        "PayDetails2",
                                                        "PayDetails2Source",
                                                        "PayDetails3",
                                                        "PayDetails3Source",
                                                        "PayDetails4",
                                                        "PayDetails4Source",
                                                        "SettlementMeans",
                                                        "SettlementMeansSource",
                                                        "SettlementAccount",
                                                        "SettlementAccountSource",
                                                        "TradeEffectiveDate",
                                                        "TradeEffectiveDateSource",
                                                        "SafeKeepAccount",
                                                        "SafeKeepAccountSource",
                                                        "AccountForCharges1",
                                                        "AccountForCharges1Source",
                                                        "AccountForCharges2",
                                                        "AccountForCharges2Source",
                                                        "AccountForCharges3",
                                                        "AccountForCharges3Source",
                                                        "AccountForCharges4",
                                                        "AccountForCharges4Source",
                                                        "AccountForCharges5",
                                                        "AccountForCharges5Source",
                                                        "AccountForCharges6",
                                                        "AccountForCharges6Source",
                                                        "FormatBoth541543",
                                                        "FormatBoth541543Source",
                                                        "UsualId",
                                                        "UsualIdSource",
                                                        "Spare1",
                                                        "Spare1Source",
                                                        "Spare2",
                                                        "Spare2Source",
                                                        "Spare3",
                                                        "Spare3Source",
                                                        "Spare4",
                                                        "Spare4Source",
                                                        "Spare5",
                                                        "Spare5Source",
                                                        "ScBic",
                                                        "ScBicSource",
                                                        "ScAccountNumber",
                                                        "ScAccountNumberSource",
                                                        "FiAutoAuthorize",
                                                        "FiAutoAuthorizeSource",
                                                        "FiSwiftSuppress",
                                                        "FiSwiftSuppressSource",
                                                        "SynSettlementMethod",
                                                        "SynSettlementMethodSource",
                                                        "AutoSettle",
                                                        "AutoSettleSource",
                                                        "SettlementNarrative",
                                                        "SettlementNarrativeSource",
                                                        "FlowNature",
                                                        "FlowNatureSource",
                                                        "Instrument",
                                                        "InstrumentSource",
                                                        "Typology",
                                                        "TypologySource",
                                                        "Usage",
                                                        "UsageSource",
                                                        "TradeCustomInfo",
                                                        "TradeCustomInfoSource",
                                                        "IsThirdParty",
                                                        "IsThirdPartySource"
                                                        )) from "SSI" where "oid"=objoid;


 -- SSI#_a Table Cursors
 cursor cur_ssi#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SSI#__a') order by column_id;

 cursor cur_ssi#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                       "ClassOfAccountSource"	,
                                                        "SettContact"	,
                                                        "SettContactSource"	,
                                                        "SettPhone"	,
                                                        "SettPhoneSource"	,
                                                        "SpecialInstruction1"	,
                                                        "SpecialInstruction1Source"	,
                                                        "SpecialInstruction2"	,
                                                        "SpecialInstruction2Source"	,
                                                        "AlertRelationship"	,
                                                        "AlertRelationshipSource"	,
                                                        "oid"	,
                                                        "TradingAccount"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "Security"	,
                                                        "SecuritySource"	,
                                                        "SettlementMethod"	,
                                                        "SettlementMethodSource"	,
                                                        "AlertIndex"	,
                                                        "Currency"	,
                                                        "CurrencySource"	,
                                                        "AltCurrency"	,
                                                        "AltCurrencySource"	,
                                                        "DefaultSsi"	,
                                                        "DefaultSsiSource"	,
                                                        "TermsOfDelivery"	,
                                                        "TermsOfDeliverySource"	,
                                                        "SettlementType"	,
                                                        "SettlementTypeSource"	,
                                                        "ClassOfAccount",
                                                        "ConfirmationMethod",
                                                        "ConfirmationMethodSource",
                                                        "AddCustodianToMT304Tag57",
                                                        "AddCustodianToMT304Tag57Source",
                                                        "BranchId",
                                                        "BranchIdSource",
                                                        "SettlementCode",
                                                        "SettlementCodeSource",
                                                        "Charges",
                                                        "ChargesSource",
                                                        "CmsAccount",
                                                        "CmsAccountSource",
                                                        "AebAccount",
                                                        "AebAccountSource",
                                                        "FiscAccount",
                                                        "FiscAccountSource",
                                                        "FinCopy",
                                                        "FinCopySource",
                                                        "CmsAccountNumber",
                                                        "CmsAccountNumberSource",
                                                        "SenderToReceiver1",
                                                        "SenderToReceiver1Source",
                                                        "SenderToReceiver2",
                                                        "SenderToReceiver2Source",
                                                        "SenderToReceiver3",
                                                        "SenderToReceiver3Source",
                                                        "SenderToReceiver4",
                                                        "SenderToReceiver4Source",
                                                        "SenderToReceiver5",
                                                        "SenderToReceiver5Source",
                                                        "SenderToReceiver6",
                                                        "SenderToReceiver6Source",
                                                        "SwiftType",
                                                        "SwiftTypeSource",
                                                        "DebitCredit",
                                                        "DebitCreditSource",
                                                        "PayDetails1",
                                                        "PayDetails1Source",
                                                        "PayDetails2",
                                                        "PayDetails2Source",
                                                        "PayDetails3",
                                                        "PayDetails3Source",
                                                        "PayDetails4",
                                                        "PayDetails4Source",
                                                        "SettlementMeans",
                                                        "SettlementMeansSource",
                                                        "SettlementAccount",
                                                        "SettlementAccountSource",
                                                        "TradeEffectiveDate",
                                                        "TradeEffectiveDateSource",
                                                        "SafeKeepAccount",
                                                        "SafeKeepAccountSource",
                                                        "AccountForCharges1",
                                                        "AccountForCharges1Source",
                                                        "AccountForCharges2",
                                                        "AccountForCharges2Source",
                                                        "AccountForCharges3",
                                                        "AccountForCharges3Source",
                                                        "AccountForCharges4",
                                                        "AccountForCharges4Source",
                                                        "AccountForCharges5",
                                                        "AccountForCharges5Source",
                                                        "AccountForCharges6",
                                                        "AccountForCharges6Source",
                                                        "FormatBoth541543",
                                                        "FormatBoth541543Source",
                                                        "UsualId",
                                                        "UsualIdSource",
                                                        "Spare1",
                                                        "Spare1Source",
                                                        "Spare2",
                                                        "Spare2Source",
                                                        "Spare3",
                                                        "Spare3Source",
                                                        "Spare4",
                                                        "Spare4Source",
                                                        "Spare5",
                                                        "Spare5Source",
                                                        "ScBic",
                                                        "ScBicSource",
                                                        "ScAccountNumber",
                                                        "ScAccountNumberSource",
                                                        "FiAutoAuthorize",
                                                        "FiAutoAuthorizeSource",
                                                        "FiSwiftSuppress",
                                                        "FiSwiftSuppressSource",
                                                        "SynSettlementMethod",
                                                        "SynSettlementMethodSource",
                                                        "AutoSettle",
                                                        "AutoSettleSource",
                                                        "SettlementNarrative",
                                                        "SettlementNarrativeSource",
                                                        "FlowNature",
                                                        "FlowNatureSource",
                                                        "Instrument",
                                                        "InstrumentSource",
                                                        "Typology",
                                                        "TypologySource",
                                                        "Usage",
                                                        "UsageSource",
                                                        "TradeCustomInfo",
                                                        "TradeCustomInfoSource",
                                                        "IsThirdParty",
                                                        "IsThirdPartySource"
                                                        )) from "SSI#__a" where "oid"=objoid order by "__version";


 -- SSI#SetChain Table Cursors
 cursor cur_ssi#setchain_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SSI#SetChain') order by column_id;

 cursor cur_ssi#setchain_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "StepType"	,
                                                        "StepTypeSource"	,
                                                        "SettlementAgentName"	,
                                                        "SettlementAgentNameSource"	,
                                                        "SettlementAgentName2"	,
                                                        "SettlementAgentName2Source"	,
                                                        "SettlementAgentName3"	,
                                                        "SettlementAgentName3Source"	,
                                                        "SettlementAgentId"	,
                                                        "SettlementAgentIdSource"	,
                                                        "Address1"	,
                                                        "Address1Source"	,
                                                        "Address2"	,
                                                        "Address2Source"	,
                                                        "City"	,
                                                        "CitySource"	,
                                                        "Locality"	,
                                                        "LocalitySource"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "PostCode"	,
                                                        "PostCodeSource"	,
                                                        "Bic"	,
                                                        "BicSource"	,
                                                        "AccountName"	,
                                                        "AccountNameSource"	,
                                                        "AccountName2"	,
                                                        "AccountName2Source"	,
                                                        "AccountNumber"	,
                                                        "AccountNumberSource"	,
                                                        "SubAccountNumber"	,
                                                        "SubAccountNumberSource"	,
                                                        "SubAccountName"	,
                                                        "SubAccountNameSource"	,
                                                        "SubAccountName2"	,
                                                        "SubAccountName2Source"	,
                                                        "ParticipantName"	,
                                                        "ParticipantNameSource"	,
                                                        "ParticipantName2"	,
                                                        "ParticipantName2Source"	,
                                                        "OriginalStepIndex"	,
                                                        "OriginalStepIndexSource"	,
                                                        "AdditionalInfo1"	,
                                                        "AdditionalInfo1Source"	,
                                                        "AdditionalInfo2"	,
                                                        "AdditionalInfo2Source"	,
                                                        "IdentifierType"	,
                                                        "IdentifierTypeSource"	,
                                                        "CashAccountNum"	,
                                                        "CashAccountNumSource"	,
                                                        "AltCashAccountNum"	,
                                                        "AltCashAccountNumSource"	,
                                                        "PhoneNumber"	,
                                                        "PhoneNumberSource"	,
                                                        "ContactName"	,
                                                        "ContactNameSource"	,
                                                        "SettlementInstitution"	,
                                                        "SettlementInstitutionSource"
                                                        )) from "SSI#SetChain" where "oid"=objoid;


 -- SSI#SetChain#_a Table Cursors
 cursor cur_ssi#setchain#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SSI#SetChain#__a') order by column_id;

 cursor cur_ssi#setchain#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "StepType"	,
                                                        "StepTypeSource"	,
                                                        "SettlementAgentName"	,
                                                        "SettlementAgentNameSource"	,
                                                        "SettlementAgentName2"	,
                                                        "SettlementAgentName2Source"	,
                                                        "SettlementAgentName3"	,
                                                        "SettlementAgentName3Source"	,
                                                        "SettlementAgentId"	,
                                                        "SettlementAgentIdSource"	,
                                                        "Address1"	,
                                                        "Address1Source"	,
                                                        "Address2"	,
                                                        "Address2Source"	,
                                                        "City"	,
                                                        "CitySource"	,
                                                        "Locality"	,
                                                        "LocalitySource"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "PostCode"	,
                                                        "PostCodeSource"	,
                                                        "Bic"	,
                                                        "BicSource"	,
                                                        "AccountName"	,
                                                        "AccountNameSource"	,
                                                        "AccountName2"	,
                                                        "AccountName2Source"	,
                                                        "AccountNumber"	,
                                                        "AccountNumberSource"	,
                                                        "SubAccountNumber"	,
                                                        "SubAccountNumberSource"	,
                                                        "SubAccountName"	,
                                                        "SubAccountNameSource"	,
                                                        "SubAccountName2"	,
                                                        "SubAccountName2Source"	,
                                                        "ParticipantName"	,
                                                        "ParticipantNameSource"	,
                                                        "ParticipantName2"	,
                                                        "ParticipantName2Source"	,
                                                        "OriginalStepIndex"	,
                                                        "OriginalStepIndexSource"	,
                                                        "AdditionalInfo1"	,
                                                        "AdditionalInfo1Source"	,
                                                        "AdditionalInfo2"	,
                                                        "AdditionalInfo2Source"	,
                                                        "IdentifierType"	,
                                                        "IdentifierTypeSource"	,
                                                        "CashAccountNum"	,
                                                        "CashAccountNumSource"	,
                                                        "AltCashAccountNum"	,
                                                        "AltCashAccountNumSource"	,
                                                        "PhoneNumber"	,
                                                        "PhoneNumberSource"	,
                                                        "ContactName"	,
                                                        "ContactNameSource"	,
                                                        "SettlementInstitution"	,
                                                        "SettlementInstitutionSource"
                                                        )) from "SSI#SetChain#__a" where "oid"=objoid order by "__version", "docOrder" asc;



 -- TradAcc Table Cursors
 cursor cur_tradacc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc') order by column_id;

 cursor cur_tradacc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "Counterparty"	,
                                                        "IsSkeletonAccount"	,
                                                        "AccountNetOrgCode"	,
                                                        "AccountNetOrgCodeSource"	,
                                                        "AccountNetAccountCode"	,
                                                        "AccountNetAccountCodeSource"	,
                                                        "LocalAcronym"	,
                                                        "AlertAcronym"	,
                                                        "AlertAcronymSource"	,
                                                        "AlertAccessCode"	,
                                                        "AlertAccessCodeSource"	,
														"SciLeid",
														"SciLeidSource",
                                                        "ShortName"	,
                                                        "ShortNameSource"	,
                                                        "LongName"	,
                                                        "LongNameSource"	,
                                                        "FullName"	,
                                                        "FullNameSource"	,
                                                        "RiskCountry"	,
                                                        "RiskCountrySource"	,
                                                        "Nationality"	,
                                                        "NationalitySource"	,
                                                        "CustInternalAcNo"	,
                                                        "CustInternalAcNoSource"	,
                                                        "InstitutionName"	,
                                                        "InstitutionNameSource"	,
                                                        "InstitutionBic"	,
                                                        "InstitutionBicSource"	,
                                                        "TaxExempt"	,
                                                        "TaxExemptSource"	,
                                                        "TaxWithhold"	,
                                                        "TaxWithholdSource"	,
                                                        "CharityAccountRef"	,
                                                        "CharityAccountRefSource"	,
                                                        "TaxID"	,
                                                        "TaxIDSource",
                                                        "ClsCustomType",
                                                        "AlertTrustedSrc",
                                                        "AlertTrustedSrcSource",
                                                        "SegmentCode",
                                                        "SegmentCodeSource",
                                                        "LongName1",
                                                        "LongName1Source",
                                                        "Address",
                                                        "AddressSource",
                                                        "City",
                                                        "CitySource",
														"ActualLegalName",
														"ActualLegalNameSource",
														"NDAApplicable",
														"NDAApplicableSource",
														"CptyAccNo",
														"CptyAccNoSource",
														"CptyType",
														"CptyTypeSource",
														"FinInstType",
														"FinInstTypeSource",
														"CptyBIC",
														"CptyBICSource"
                                                        )) from "TradAcc" where "oid"=objoid;


 -- TradAcc#_a Table Cursors
 cursor cur_tradacc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#__a') order by column_id;

 cursor cur_tradacc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "Counterparty"	,
                                                        "IsSkeletonAccount"	,
                                                        "AccountNetOrgCode"	,
                                                        "AccountNetOrgCodeSource"	,
                                                        "AccountNetAccountCode"	,
                                                        "AccountNetAccountCodeSource"	,
                                                        "LocalAcronym"	,
                                                        "AlertAcronym"	,
                                                        "AlertAcronymSource"	,
                                                        "AlertAccessCode"	,
                                                        "AlertAccessCodeSource"	,
														"SciLeid",
														"SciLeidSource",
                                                        "ShortName"	,
                                                        "ShortNameSource"	,
                                                        "LongName"	,
                                                        "LongNameSource"	,
                                                        "FullName"	,
                                                        "FullNameSource"	,
                                                        "RiskCountry"	,
                                                        "RiskCountrySource"	,
                                                        "Nationality"	,
                                                        "NationalitySource"	,
                                                        "CustInternalAcNo"	,
                                                        "CustInternalAcNoSource"	,
                                                        "InstitutionName"	,
                                                        "InstitutionNameSource"	,
                                                        "InstitutionBic"	,
                                                        "InstitutionBicSource"	,
                                                        "TaxExempt"	,
                                                        "TaxExemptSource"	,
                                                        "TaxWithhold"	,
                                                        "TaxWithholdSource"	,
                                                        "CharityAccountRef"	,
                                                        "CharityAccountRefSource"	,
                                                        "TaxID"	,
                                                        "TaxIDSource",
                                                        "ClsCustomType",
                                                        "AlertTrustedSrc",
                                                        "AlertTrustedSrcSource",
                                                        "SegmentCode",
                                                        "SegmentCodeSource",
                                                        "LongName1",
                                                        "LongName1Source",
                                                        "Address",
                                                        "AddressSource",
                                                        "City",
                                                        "CitySource",
														"ActualLegalName",
														"ActualLegalNameSource",
														"NDAApplicable",
														"NDAApplicableSource",
														"CptyAccNo",
														"CptyAccNoSource",
														"CptyType",
														"CptyTypeSource",
														"FinInstType",
														"FinInstTypeSource",
														"CptyBIC",
														"CptyBICSource"
                                                        )) from "TradAcc#__a" where "oid"=objoid order by "__version";


 -- TradAcc#AvMarkets Table Cursors
 cursor cur_tradacc#av_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#AvMarkets') order by column_id;

 cursor cur_tradacc#av_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "AlertIndex"	,
                                                        "AccountNetModelName"
                                                        )) from "TradAcc#AvMarkets" where "oid"=objoid;


 -- TradAcc#AvMarkets#_a Table Cursors
 cursor cur_tradacc#av#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#AvMarkets#__a') order by column_id;

 cursor cur_tradacc#av#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "AlertIndex"	,
                                                        "AccountNetModelName"
                                                        )) from "TradAcc#AvMarkets#__a" where "oid"=objoid order by "__version", "docOrder" asc;




 -- TradAcc#MarketFilters Table Cursors
 cursor cur_tradacc#mf_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#MarketFilters') order by column_id;

 cursor cur_tradacc#mf_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "Effect"
                                                        )) from "TradAcc#MarketFilters" where "oid"=objoid;


 -- TradAcc#MarketFilters#_a Table Cursors
 cursor cur_tradacc#mf#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#MarketFilters#__a') order by column_id;

 cursor cur_tradacc#mf#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "Effect"
                                                        )) from "TradAcc#MarketFilters#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- TradAcc#MktFilterSets Table Cursors
 cursor cur_tradacc#mfs_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#MktFilterSets') order by column_id;

 cursor cur_tradacc#mfs_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "MarketFilterSets"
                                                        )) from "TradAcc#MktFilterSets" where "oid"=objoid;


 -- TradAcc#MktFilterSets#_a Table Cursors
 cursor cur_tradacc#mfs#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradAcc#MktFilterSets#__a') order by column_id;

 cursor cur_tradacc#mfs#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "MarketFilterSets"
                                                        )) from "TradAcc#MktFilterSets#__a" where "oid"=objoid order by "__version", "docOrder" asc;


 -- Cpty Table Cursors
 cursor cur_cpty_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty') order by column_id;

 cursor cur_cpty_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "Parent"	,
                                                        "ParentSource"	,
                                                        "ShortName"	,
                                                        "ShortNameSource"	,
                                                        "LongName"	,
                                                        "LongNameSource"	,
                                                        "FullName"	,
                                                        "FullNameSource"	,
                                                        "RiskCountry"	,
                                                        "RiskCountrySource"	,
                                                        "Nationality"	,
                                                        "NationalitySource"	,
                                                        "CounterpartyType"	,
                                                        "CounterpartyTypeSource"	,
                                                        "AccountNetOrgCode"	,
                                                        "AccountNetOrgCodeSource"	,
                                                        "AllowedAccountNetOrgCodeSource"	,
                                                        "AlertAcronym"	,
                                                        "AlertAcronymSource"	,
                                                        "AllowedAlertAcronymsSource"	,
                                                        "IsAcceptingNewAcc"	,
                                                        "OverrideLAIncFilters"
                                                        )) from "Cpty" where "oid"=objoid;


 -- Cpty#_a Table Cursors
 cursor cur_cpty#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty#__a') order by column_id;

 cursor cur_cpty#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "Parent"	,
                                                        "ParentSource"	,
                                                        "ShortName"	,
                                                        "ShortNameSource"	,
                                                        "LongName"	,
                                                        "LongNameSource"	,
                                                        "FullName"	,
                                                        "FullNameSource"	,
                                                        "RiskCountry"	,
                                                        "RiskCountrySource"	,
                                                        "Nationality"	,
                                                        "NationalitySource"	,
                                                        "CounterpartyType"	,
                                                        "CounterpartyTypeSource"	,
                                                        "AccountNetOrgCode"	,
                                                        "AccountNetOrgCodeSource"	,
                                                        "AllowedAccountNetOrgCodeSource"	,
                                                        "AlertAcronym"	,
                                                        "AlertAcronymSource"	,
                                                        "AllowedAlertAcronymsSource"	,
                                                        "IsAcceptingNewAcc"	,
                                                        "OverrideLAIncFilters"
                                                        )) from "Cpty#__a" where "oid"=objoid order by "__version";



 -- Cpty#CustFilter Table Cursors
 cursor cur_cpty#cf_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty#CustFilter') order by column_id;

 cursor cur_cpty#cf_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "Effect"
                                                        )) from "Cpty#CustFilter" where "oid"=objoid;


 -- Cpty#CustFilter#_a Table Cursors
 cursor cur_cpty#cf#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty#CustFilter#__a') order by column_id;

 cursor cur_cpty#cf#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "Country"	,
                                                        "Security"	,
                                                        "Method"	,
                                                        "Effect"
                                                        )) from "Cpty#CustFilter#__a" where "oid"=objoid order by "__version", "docOrder" asc;



 -- Cpty#MktFilterSet Table Cursors
 cursor cur_cpty#mfs_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty#MktFilterSet') order by column_id;

 cursor cur_cpty#mfs_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "MarketFilterSets"
                                                        )) from "Cpty#MktFilterSet" where "oid"=objoid;


 -- Cpty#MktFilterSet#_a Table Cursors
 cursor cur_cpty#mfs#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Cpty#MktFilterSet#__a') order by column_id;

 cursor cur_cpty#mfs#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "eid"	,
                                                        "docOrder"	,
                                                        "MarketFilterSets"
                                                        )) from "Cpty#MktFilterSet#__a" where "oid"=objoid order by "__version", "docOrder" asc;



 -- TradeConfirm Table Cursors
 cursor cur_tc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradeConfirm') order by column_id;

 cursor cur_tc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "TradingAccount"	,
                                                        "AccountNetId"	,
                                                        "AlertIndex"	,
                                                        "ConfirmPriority"	,
                                                        "ConfirmCode"	,
                                                        "ConfirmCodeSource"	,
                                                        "ConfirmName"	,
                                                        "ConfirmNameSource"
                                                        )) from "TradeConfirm" where "oid"=objoid;


 -- TradeConfirm#_a Table Cursors
 cursor cur_tc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TradeConfirm#__a') order by column_id;

 cursor cur_tc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "TradingAccount"	,
                                                        "AccountNetId"	,
                                                        "AlertIndex"	,
                                                        "ConfirmPriority"	,
                                                        "ConfirmCode"	,
                                                        "ConfirmCodeSource"	,
                                                        "ConfirmName"	,
                                                        "ConfirmNameSource"
                                                        )) from "TradeConfirm#__a" where "oid"=objoid order by "__version";


 -- EtcConfirm Table Cursors
 cursor cur_ec_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'EtcConfirm') order by column_id;

 cursor cur_ec_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "OasysAcronym"	,
                                                        "OasysAcronymSource"	,
                                                        "OasysAccessCode"	,
                                                        "OasysAccessCodeSource"	,
                                                        "OtherETCCode"	,
                                                        "OtherETCCodeSource"
                                                        )) from "EtcConfirm" where "oid"=objoid;


 -- EtcConfirm#_a Table Cursors
 cursor cur_ec#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'EtcConfirm#__a') order by column_id;

 cursor cur_ec#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "OasysAcronym"	,
                                                        "OasysAcronymSource"	,
                                                        "OasysAccessCode"	,
                                                        "OasysAccessCodeSource"	,
                                                        "OtherETCCode"	,
                                                        "OtherETCCodeSource"
                                                        )) from "EtcConfirm#__a" where "oid"=objoid order by "__version";


 -- FaxConfirm Table Cursors
 cursor cur_fc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'FaxConfirm') order by column_id;

 cursor cur_fc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "FaxNumber"	,
                                                        "FaxNumberSource"	,
                                                        "FaxNumber2"	,
                                                        "FaxNumber2Source"
                                                        )) from "FaxConfirm" where "oid"=objoid;


 -- FaxConfirm#_a Table Cursors
 cursor cur_fc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'FaxConfirm#__a') order by column_id;

 cursor cur_fc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "FaxNumber"	,
                                                        "FaxNumberSource"	,
                                                        "FaxNumber2"	,
                                                        "FaxNumber2Source"
                                                        )) from "FaxConfirm#__a" where "oid"=objoid order by "__version";



 -- PhoneConfirm Table Cursors
 cursor cur_phonec_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'PhoneConfirm') order by column_id;

 cursor cur_phonec_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "TelNumber"	,
                                                        "TelNumberSource"	,
                                                        "TelNumber2"	,
                                                        "TelNumber2Source"
                                                        )) from "PhoneConfirm" where "oid"=objoid;


 -- PhoneConfirm#_a Table Cursors
 cursor cur_phonec#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'PhoneConfirm#__a') order by column_id;

 cursor cur_phonec#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "TelNumber"	,
                                                        "TelNumberSource"	,
                                                        "TelNumber2"	,
                                                        "TelNumber2Source"
                                                        )) from "PhoneConfirm#__a" where "oid"=objoid order by "__version";


 -- PostalAddressConfirm Table Cursors
 cursor cur_postc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'PostalAddressConfirm') order by column_id;

 cursor cur_postc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "Department"	,
                                                        "DepartmentSource"	,
                                                        "Company"	,
                                                        "CompanySource"	,
                                                        "AddressLine1"	,
                                                        "AddressLine1Source"	,
                                                        "AddressLine2"	,
                                                        "AddressLine2Source"	,
                                                        "AddressLine3"	,
                                                        "AddressLine3Source"	,
                                                        "StreetRoadAve"	,
                                                        "StreetRoadAveSource"	,
                                                        "CityCounty"	,
                                                        "CityCountySource"	,
                                                        "StateRegion"	,
                                                        "StateRegionSource"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "PostCode"	,
                                                        "PostCodeSource"
                                                        )) from "PostalAddressConfirm" where "oid"=objoid;


 -- PostalAddressConfirm#_a Table Cursors
 cursor cur_postc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'PostalAddressConfirm#__a') order by column_id;

 cursor cur_postc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "Department"	,
                                                        "DepartmentSource"	,
                                                        "Company"	,
                                                        "CompanySource"	,
                                                        "AddressLine1"	,
                                                        "AddressLine1Source"	,
                                                        "AddressLine2"	,
                                                        "AddressLine2Source"	,
                                                        "AddressLine3"	,
                                                        "AddressLine3Source"	,
                                                        "StreetRoadAve"	,
                                                        "StreetRoadAveSource"	,
                                                        "CityCounty"	,
                                                        "CityCountySource"	,
                                                        "StateRegion"	,
                                                        "StateRegionSource"	,
                                                        "Country"	,
                                                        "CountrySource"	,
                                                        "PostCode"	,
                                                        "PostCodeSource"
                                                        )) from "PostalAddressConfirm#__a" where "oid"=objoid order by "__version";


 -- TelexConfirm Table Cursors
 cursor cur_telexc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TelexConfirm') order by column_id;

 cursor cur_telexc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "Telex"	,
                                                        "TelexSource"	,
                                                        "Telex2"	,
                                                        "Telex2Source"
                                                        )) from "TelexConfirm" where "oid"=objoid;


 -- TelexConfirm#_a Table Cursors
 cursor cur_telexc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'TelexConfirm#__a') order by column_id;

 cursor cur_telexc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "AttentionOf"	,
                                                        "AttentionOfSource"	,
                                                        "Telex"	,
                                                        "TelexSource"	,
                                                        "Telex2"	,
                                                        "Telex2Source"
                                                        )) from "TelexConfirm#__a" where "oid"=objoid order by "__version";

 -- SwiftConfirm Table Cursors
 cursor cur_swiftc_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SwiftConfirm') order by column_id;

 cursor cur_swiftc_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "SwiftAddress"	,
                                                        "SwiftAddressSource"
                                                        )) from "SwiftConfirm" where "oid"=objoid;


 -- SwiftConfirm#_a Table Cursors
 cursor cur_swiftc#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'SwiftConfirm#__a') order by column_id;

 cursor cur_swiftc#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "SwiftAddress"	,
                                                        "SwiftAddressSource"
                                                        )) from "SwiftConfirm#__a" where "oid"=objoid order by "__version";

 -- Contact Table Cursors
 cursor cur_contact_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Contact') order by column_id;

 cursor cur_contact_data is select XMLELEMENT("row", XMLAttributes(
                                                        "oid"	,
                                                        "ContactType"	,
                                                        "ParentAssassinObject"	,
                                                        "Forename"	,
                                                        "ForenameSource"	,
                                                        "Surname"	,
                                                        "SurnameSource"	,
                                                        "EmailAddress"	,
                                                        "EmailAddressSource"	,
                                                        "PhoneNumber"	,
                                                        "PhoneNumberSource"	,
                                                        "FaxNumber"	,
                                                        "FaxNumberSource"	,
                                                        cast("ContactNotes" as varchar2(500)) as "ContactNotes"	,
                                                        "ContactNotesSource"
                                                        )) from "Contact" where "oid"=objoid;


-- Object Change Table Cursors
cursor curObjChg#_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'ObjectChange') order by column_id;


 cursor curObjChg#_data is select XMLELEMENT("row", XMLAttributes(
                                                        "SequenceNumber"	,
                                                        "Processor"	,
                                                        "CreationDate"	,
                                                        "ProcessDate"	,
                                                        "Version"	,
                                                        "ObjectRef"	,
                                                        "ChangeEditor"	,
                                                        "ChangeObjectType"	,
                                                        "ChangeObjectAssembly"	,
                                                        "ChangeType"	,
                                                        "ProcessingState"	,
                                                        "CreationReason"	,
                                                        cast ("ExceptionText" as varchar2(500)) as "ExceptionText",
														"LimitedRetryAttemptNum"	))
														from "ObjectChange" where "ObjectRef"=objoid order by "CreationDate";


-- Object Record Table Cursors
cursor curObjChgRecord#_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'ObjectChangeRecord') order by column_id;


 cursor curObjChgRecord#_data is select XMLELEMENT("row", XMLAttributes(
														"oid",
                                                        "SequenceNumber"	,
                                                        "Processor"	,
                                                        "CreationDate"	,
                                                        "ProcessDate"	,
                                                        "Version"	,
                                                        "ObjectRef"	,
                                                        "ChangeEditor"	,
                                                        "ChangeObjectType"	,
                                                        "ChangeObjectAssembly"	,
                                                        "ChangeType"	,
                                                        "ProcessingState"	,
                                                        "CreationReason"	,
                                                        cast ("ExceptionText" as varchar2(500)) as "ExceptionText",
														"LimitedRetryAttemptNum"	))
														from "ObjectChangeRecord" where "ObjectRef"=objoid order by "CreationDate";


-- Object Record Table Cursors
cursor curObjChgProc#_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'ObjChangeProc') order by column_id;


 cursor curObjChgProc#_data is select XMLELEMENT("row", XMLAttributes(
														"oid",
                                                        "Id"	,
                                                        "ProcessorTypeName"	,
                                                        "ProcessorAssemblyName"	,
                                                        "DisplayName"	,
                                                        "ProcessingActive"	,
                                                        "CreationActive"	,
                                                        "ProcessorGroup"	))
														from "ObjChangeProc";


-- StateMachine record cursors
 cursor cur_SMAction_header is SELECT
 XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
			WHERE (table_name =  'SMQueue' AND column_name IN ('oid','SequenceNumber',
				'SetProcessingState','ActionCreatedDate','QueuedActionSetType', 'UserToImpersonate',
				'SetProcessingStartDate','SetProcessingEndDate'))
               OR (table_name =  'SMQueue#Action' AND column_name IN
				('eid','docOrder',
				'AssassinObject','UserType','Action','ProcessingState','ActionAttempts','ActionError',
				'ActionProcessingStartDate','ActionProcessingEndDate','AdditionalParameters'))
			ORDER BY table_name, column_id;


 cursor cur_SMAction_data is SELECT
			XMLELEMENT("row", XMLAttributes(p."oid",p."SequenceNumber",p."SetProcessingState",
      p."ActionCreatedDate",p."QueuedActionSetType",p."UserToImpersonate",p."SetProcessingStartDate",
      p."SetProcessingEndDate",c."eid",c."docOrder",c."AssassinObject",c."UserType",c."Action",
      c."ProcessingState",c."ActionAttempts",cast(c."ActionError" as varchar2(500)) as "ActionError",
	  c."ActionProcessingStartDate", c."ActionProcessingEndDate", cast (c."AdditionalParameters"as varchar2(500)) as "AdditionalParameters"))
			from "SMQueue" p
				join "SMQueue#Action" c on p."oid" = c."oid"
			where c."AssassinObject" = objoid
			order by "SequenceNumber";



 -- Contact#_a Table Cursors
 cursor cur_contact#a_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'Contact#__a') order by column_id;

 cursor cur_contact#a_data is select XMLELEMENT("row", XMLAttributes(
                                                        "__version"	,
                                                        "__action"	,
                                                        "oid"	,
                                                        "ContactType"	,
                                                        "ParentAssassinObject"	,
                                                        "Forename"	,
                                                        "ForenameSource"	,
                                                        "Surname"	,
                                                        "SurnameSource"	,
                                                        "EmailAddress"	,
                                                        "EmailAddressSource"	,
                                                        "PhoneNumber"	,
                                                        "PhoneNumberSource"	,
                                                        "FaxNumber"	,
                                                        "FaxNumberSource"	,
                                                        cast("ContactNotes" as varchar2(500)) as "ContactNotes"	,
                                                        "ContactNotesSource"
                                                        )) from "Contact#__a" where "oid"=objoid order by "__version";


cursor cur_tradacc_ssi_sum_header is
SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
FROM USER_TAB_COLUMNS
WHERE (table_name =  'SSI'  AND column_name IN ('oid', 'Country', 'Security','SettlementMethod','AlertIndex'))
               OR (table_name =  'AssObj#__i'  AND column_name IN ('creationDate'))
               OR (table_name =  'AssObj' AND column_name IN ('ChangeState'))
               OR (table_name =  'AssObj#Core'  AND column_name IN ('DataSource')) order by table_name desc;


cursor cur_tradacc_ssi_sum_data is
SELECT XMLELEMENT("row", XMLAttributes( ssi."oid" as "oid",
                                  cun."DisplayName" as "Country",
                                  sec."DisplayName" as "Security",
                                  met."DisplayName" as "SettlementMethod",
                                  aoi."creationDate" as "creationDate",
                                  ssi."AlertIndex" as "AlertIndex",
                                  cs."EnumText" as "ChangeState",
                                  aoc."DataSource" as "DataSource"))
FROM "SSI" ssi
join "Country" cun on cun."oid" = ssi."Country"
join "Security" sec on sec."oid" = ssi."Security"
join "Method" met on met."oid" = ssi."SettlementMethod"
join "AssObj#Core" aoc on aoc."oid" = ssi."oid"
join "AssObj#__i" aoi on aoi."oid" = ssi."oid"
join "AssObj" a on a."oid" = ssi."oid"
left join "EnumLookup" cs on cs."EnumValue" = a."ChangeState" and cs."TypeName"='ChangeState'
WHERE ssi."TradingAccount" = objoid;


 -- DownstreamSystemStatus Table Cursors
 cursor cur_dss_header is
 SELECT XMLELEMENT("row", XMLAttributes(column_name as "column_name"))
 FROM USER_TAB_COLUMNS
 WHERE (table_name = 'DownstreamSystemStatus') order by column_id;


 cursor cur_dss_data is select XMLELEMENT("row", XMLAttributes(
                                                        "SequenceNumber"	,
                                                        "AssassinObject"	,
                                                        "AssassinObjectVersion"	,
                                                        "StatusReportReceviedAt"	,
                                                        "DownstreamSystemTypeId"	,
                                                        "DownstreamSystemState"	,
                                                        "ErrorCategory"	,
                                                        "ErrorSubCategory"	,
                                                        "ErrorDescription"	,
                                                        "StatusChangedAt"	,
                                                        "StatusUpdateStage"
                                                        )) from "DownstreamSystemStatus" where "AssassinObject"=objoid order by "SequenceNumber";



begin
 xmlObjectString := '<?xml version="1.0" encoding="UTF-8"?>';

 xmlObjectString := xmlObjectString || '<?xml-stylesheet type="text/xsl" href="ObjectTransform.xslt"?>';


--Report Start
 select systimestamp into datetime from dual;

 xmlObjectString := xmlObjectString || '<report oid="'||objoid||'" date="'|| datetime || '">';


-- Version Summary --
 xmlObjectString := xmlObjectString || '<table name="Version Summary"><header>';

  Open cur_sum_header;

  Loop
   Fetch cur_sum_header into xml;

   Exit when not cur_sum_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

  End Loop;

  Close cur_sum_header;

  xmlObjectString := xmlObjectString || '</header><data>';

  Open cur_sum_data;

  Loop
   Fetch cur_sum_data into xml;

   Exit when not cur_sum_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

  End Loop;

  Close cur_sum_data;

  xmlObjectString := xmlObjectString || '</data></table>';


 -- AssassinObject --
 xmlObjectString := xmlObjectString || '<table name="AssObj"><header>';

 Open cur_assobj_header;

 Loop
  Fetch cur_assobj_header into xml;

  Exit when not cur_assobj_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj_data;

 Loop
  Fetch cur_assobj_data into xml;

  Exit when not cur_assobj_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssaObj#__i --
 xmlObjectString := xmlObjectString || '<table name="AssaObj#__i"><header>';

 Open cur_assobj#i_header;

 Loop
  Fetch cur_assobj#i_header into xml;

  Exit when not cur_assobj#i_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#i_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#i_data;

 Loop
  Fetch cur_assobj#i_data into xml;

  Exit when not cur_assobj#i_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#i_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssaObj#__a --
 xmlObjectString := xmlObjectString || '<table name="AssaObj#__a"><header>';

 Open cur_assobj#a_header;

 Loop
  Fetch cur_assobj#a_header into xml;

  Exit when not cur_assobj#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#a_data;

 Loop
  Fetch cur_assobj#a_data into xml;

  Exit when not cur_assobj#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#a_data;

  xmlObjectString := xmlObjectString || '</data></table>';


 -- AssaObj#__i#__a --
 xmlObjectString := xmlObjectString || '<table name="AssaObj#__i#__a"><header>';

 Open cur_assobj#i#a_header;

 Loop
  Fetch cur_assobj#i#a_header into xml;

  Exit when not cur_assobj#i#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#i#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#i#a_data;

 Loop
  Fetch cur_assobj#i#a_data into xml;

  Exit when not cur_assobj#i#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#i#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Change --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Change"><header>';

 Open cur_assobjchange_header;

 Loop
  Fetch cur_assobjchange_header into xml;

  Exit when not cur_assobjchange_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjchange_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobjchange_data;

 Loop
  Fetch cur_assobjchange_data into xml;

  Exit when not cur_assobjchange_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjchange_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Change#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Change#__a"><header>';

 Open cur_assobjchange#a_header;

 Loop
  Fetch cur_assobjchange#a_header into xml;

  Exit when not cur_assobjchange#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjchange#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobjchange#a_data;

 Loop
  Fetch cur_assobjchange#a_data into xml;

  Exit when not cur_assobjchange#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjchange#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Core --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Core"><header>';

 Open cur_assobjcore_header;

 Loop
  Fetch cur_assobjcore_header into xml;

  Exit when not cur_assobjcore_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjcore_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobjcore_data;

 Loop
  Fetch cur_assobjcore_data into xml;

  Exit when not cur_assobjcore_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjcore_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Core#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Core#__a"><header>';

 Open cur_assobjcore#a_header;

 Loop
  Fetch cur_assobjcore#a_header into xml;

  Exit when not cur_assobjcore#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjcore#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobjcore#a_data;

 Loop
  Fetch cur_assobjcore#a_data into xml;

  Exit when not cur_assobjcore#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobjcore#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#LatestEditors --
 xmlObjectString := xmlObjectString || '<table name="AssObj#LatestEditors"><header>';

 Open cur_assobj#le_header;

 Loop
  Fetch cur_assobj#le_header into xml;

  Exit when not cur_assobj#le_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#le_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#le_data;

 Loop
  Fetch cur_assobj#le_data into xml;

  Exit when not cur_assobj#le_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#le_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#LatestEditors#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#LatestEditors#__a"><header>';

 Open cur_assobj#le#a_header;

 Loop
  Fetch cur_assobj#le#a_header into xml;

  Exit when not cur_assobj#le#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#le#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#le#a_data;

 Loop
  Fetch cur_assobj#le#a_data into xml;

  Exit when not cur_assobj#le#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#le#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#ValFail --
 xmlObjectString := xmlObjectString || '<table name="AssObj#ValFail"><header>';

 Open cur_assobj#valfail_header;

 Loop
  Fetch cur_assobj#valfail_header into xml;

  Exit when not cur_assobj#valfail_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valfail_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#valfail_data;

 Loop
  Fetch cur_assobj#valfail_data into xml;

  Exit when not cur_assobj#valfail_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valfail_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#ValFail#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#ValFail#__a"><header>';

 Open cur_assobj#valfail#a_header;

 Loop
  Fetch cur_assobj#valfail#a_header into xml;

  Exit when not cur_assobj#valfail#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valfail#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#valfail#a_data;

 Loop
  Fetch cur_assobj#valfail#a_data into xml;

  Exit when not cur_assobj#valfail#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valfail#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


  -- AssObj#ValFail#RelObj --
 xmlObjectString := xmlObjectString || '<table name="AssObj#ValFail#RelObj"><header>';

 Open cur_assobj#valf#relo_header;

 Loop
  Fetch cur_assobj#valf#relo_header into xml;

  Exit when not cur_assobj#valf#relo_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valf#relo_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#valf#relo_data;

 Loop
  Fetch cur_assobj#valf#relo_data into xml;

  Exit when not cur_assobj#valf#relo_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valf#relo_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#ValFail#RelObj#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#ValFail#RelObj#__a"><header>';

 Open cur_assobj#valf#relo#a_header;

 Loop
  Fetch cur_assobj#valf#relo#a_header into xml;

  Exit when not cur_assobj#valf#relo#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valf#relo#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#valf#relo#a_data;

 Loop
  Fetch cur_assobj#valf#relo#a_data into xml;

  Exit when not cur_assobj#valf#relo#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#valf#relo#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#LatestReviewers --
 xmlObjectString := xmlObjectString || '<table name="AssObj#LatestReviewers"><header>';

 Open cur_assobj#lr_header;

 Loop
  Fetch cur_assobj#lr_header into xml;

  Exit when not cur_assobj#lr_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#lr_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#lr_data;

 Loop
  Fetch cur_assobj#lr_data into xml;

  Exit when not cur_assobj#lr_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#lr_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#LatestReviewers#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#LatestReviewers#__a"><header>';

 Open cur_assobj#lr#a_header;

 Loop
  Fetch cur_assobj#lr#a_header into xml;

  Exit when not cur_assobj#lr#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#lr#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#lr#a_data;

 Loop
  Fetch cur_assobj#lr#a_data into xml;

  Exit when not cur_assobj#lr#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#lr#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Notes --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Notes"><header>';

 Open cur_assobj#notes_header;

 Loop
  Fetch cur_assobj#notes_header into xml;

  Exit when not cur_assobj#notes_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#notes_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#notes_data;

 Loop
  Fetch cur_assobj#notes_data into xml;

  Exit when not cur_assobj#notes_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#notes_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#Notes#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#Notes#__a"><header>';

 Open cur_assobj#notes#a_header;

 Loop
  Fetch cur_assobj#notes#a_header into xml;

  Exit when not cur_assobj#notes#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#notes#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#notes#a_data;

 Loop
  Fetch cur_assobj#notes#a_data into xml;

  Exit when not cur_assobj#notes#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#notes#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


  -- AssObj#SystemCodes --
 xmlObjectString := xmlObjectString || '<table name="AssObj#SystemCodes"><header>';

 Open cur_assobj#syscodes_header;

 Loop
  Fetch cur_assobj#syscodes_header into xml;

  Exit when not cur_assobj#syscodes_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#syscodes_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#syscodes_data;

 Loop
  Fetch cur_assobj#syscodes_data into xml;

  Exit when not cur_assobj#syscodes_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#syscodes_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssObj#SystemCodes#__a --
 xmlObjectString := xmlObjectString || '<table name="AssObj#SystemCodes#__a"><header>';

 Open cur_assobj#syscodes#a_header;

 Loop
  Fetch cur_assobj#syscodes#a_header into xml;

  Exit when not cur_assobj#syscodes#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#syscodes#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#syscodes#a_data;

 Loop
  Fetch cur_assobj#syscodes#a_data into xml;

  Exit when not cur_assobj#syscodes#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#syscodes#a_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssaObj#__acl --
 xmlObjectString := xmlObjectString || '<table name="AssaObj#__acl"><header>';

 Open cur_assobj#acl_header;

 Loop
  Fetch cur_assobj#acl_header into xml;

  Exit when not cur_assobj#acl_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#acl_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#acl_data;

 Loop
  Fetch cur_assobj#acl_data into xml;

  Exit when not cur_assobj#acl_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#acl_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 -- AssaObj#__acl#__a --
 xmlObjectString := xmlObjectString || '<table name="AssaObj#__acl#__a"><header>';

 Open cur_assobj#acl#a_header;

 Loop
  Fetch cur_assobj#acl#a_header into xml;

  Exit when not cur_assobj#acl#a_header%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#acl#a_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_assobj#acl#a_data;

 Loop
  Fetch cur_assobj#acl#a_data into xml;

  Exit when not cur_assobj#acl#a_data%FOUND;

  xmlObjectString := xmlObjectString || xml.getStringVal();

 End Loop;

 Close cur_assobj#acl#a_data;


 xmlObjectString := xmlObjectString || '</data></table>';




 -----------------------------------------------------------------------------
-- ObjectChange --
 xmlObjectString := xmlObjectString || '<table name="ObjectChange"><header>';


 Open curObjChg#_header;

 Loop
  Fetch curObjChg#_header into xml;

  Exit when not curObjChg#_header%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChg#_header;


 xmlObjectString := xmlObjectString || '</header><data>';


 Open curObjChg#_data;


 Loop
  Fetch curObjChg#_data into xml;


  Exit when not curObjChg#_data%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChg#_data;


 xmlObjectString := xmlObjectString || '</data></table>';


 -- ObjectChangeRecord --
 xmlObjectString := xmlObjectString || '<table name="ObjectChangeRecord"><header>';


 Open curObjChgRecord#_header;

 Loop
  Fetch curObjChgRecord#_header into xml;

  Exit when not curObjChgRecord#_header%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChgRecord#_header;


 xmlObjectString := xmlObjectString || '</header><data>';


 Open curObjChgRecord#_data;


 Loop
  Fetch curObjChgRecord#_data into xml;


  Exit when not curObjChgRecord#_data%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChgRecord#_data;


 xmlObjectString := xmlObjectString || '</data></table>';



 -- ObjChangeProc --
 xmlObjectString := xmlObjectString || '<table name="ObjChangeProc"><header>';


 Open curObjChgProc#_header;

 Loop
  Fetch curObjChgProc#_header into xml;

  Exit when not curObjChgProc#_header%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChgProc#_header;


 xmlObjectString := xmlObjectString || '</header><data>';


 Open curObjChgProc#_data;


 Loop
  Fetch curObjChgProc#_data into xml;


  Exit when not curObjChgProc#_data%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close curObjChgProc#_data;


 xmlObjectString := xmlObjectString || '</data></table>';


 -- StateMachine Table Cursors
 xmlObjectString := xmlObjectString || '<table name="StateMachine"><header>';

 Open cur_SMAction_header;

 Loop
  Fetch cur_SMAction_header into xml;

  Exit when not cur_SMAction_header%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close cur_SMAction_header;


 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_SMAction_data;


 Loop
  Fetch cur_SMAction_data into xml;


  Exit when not cur_SMAction_data%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close cur_SMAction_data;

 xmlObjectString := xmlObjectString || '</data></table>';


  -- DownstreamSystemStatus --
 xmlObjectString := xmlObjectString || '<table name="DownstreamSystemStatus"><header>';


 Open cur_dss_header;


 Loop
  Fetch cur_dss_header into xml;


  Exit when not cur_dss_header%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close cur_dss_header;

 xmlObjectString := xmlObjectString || '</header><data>';


 Open cur_dss_data;


 Loop
  Fetch cur_dss_data into xml;


  Exit when not cur_dss_data%FOUND;


  xmlObjectString := xmlObjectString || xml.getStringVal();


 End Loop;


 Close cur_dss_data;

 xmlObjectString := xmlObjectString || '</data></table>';


 select count(0) into coreObjcount from "AssObj#Core" where "oid" = objoid and "ConcreteType" ='StandingSettlementInstruction';

 select count(0) into coreaObjcount from "AssObj#Core#__a" where "oid" = objoid and "ConcreteType" ='StandingSettlementInstruction';

 --SSI Tables
 if ((coreObjcount > 0) or (coreaObjcount > 0))
 then
    -- SSI --
   xmlObjectString := xmlObjectString || '<table name="SSI"><header>';

   Open cur_ssi_header;

   Loop
    Fetch cur_ssi_header into xml;

    Exit when not cur_ssi_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ssi_data;

   Loop
    Fetch cur_ssi_data into xml;

    Exit when not cur_ssi_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- SSI#__a --
   xmlObjectString := xmlObjectString || '<table name="SSI#__a"><header>';

   Open cur_ssi#a_header;

   Loop
    Fetch cur_ssi#a_header into xml;

    Exit when not cur_ssi#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ssi#a_data;

   Loop
    Fetch cur_ssi#a_data into xml;

    Exit when not cur_ssi#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- SSI#SetChain --
   xmlObjectString := xmlObjectString || '<table name="SSI#SetChain"><header>';

   Open cur_ssi#setchain_header;

   Loop
    Fetch cur_ssi#setchain_header into xml;

    Exit when not cur_ssi#setchain_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#setchain_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ssi#setchain_data;

   Loop
    Fetch cur_ssi#setchain_data into xml;

    Exit when not cur_ssi#setchain_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#setchain_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- SSI#SetChain#__a --
   xmlObjectString := xmlObjectString || '<table name="SSI#SetChain#__a"><header>';

   Open cur_ssi#setchain#a_header;

   Loop
    Fetch cur_ssi#setchain#a_header into xml;

    Exit when not cur_ssi#setchain#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#setchain#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ssi#setchain#a_data;

   Loop
    Fetch cur_ssi#setchain#a_data into xml;

    Exit when not cur_ssi#setchain#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ssi#setchain#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';
   
 -- SSI Alert Message --
 xmlObjectString := xmlObjectString || '<table name="SSI Alert Messages"><header>';

 Open cur_ssi_alert_header;
  Loop
   Fetch cur_ssi_alert_header into xml;
   Exit when not cur_ssi_alert_header%FOUND;
  xmlObjectString := xmlObjectString || xml.getStringVal();
  End Loop;
  Close cur_ssi_alert_header;
  xmlObjectString := xmlObjectString || '</header><data>';

  Open cur_ssi_alert_data;
  Loop
   Fetch cur_ssi_alert_data into xml;
   Exit when not cur_ssi_alert_data%FOUND;
   xmlObjectString := xmlObjectString || xml.getStringVal();
  End Loop;
  Close cur_ssi_alert_data;
  xmlObjectString := xmlObjectString || '</data></table>'; 

 end if;


 select count(0) into coreObjcount from "AssObj#Core" where "oid" = objoid and "ConcreteType" ='TradingAccount';

 select count(0) into coreaObjcount from "AssObj#Core#__a" where "oid" = objoid and "ConcreteType" ='TradingAccount';

 --Tradingaccount Tables
 if ((coreObjcount > 0) or (coreaObjcount > 0))
 then
    -- TradAcc --
   xmlObjectString := xmlObjectString || '<table name="TradAcc"><header>';

   Open cur_tradacc_header;

   Loop
    Fetch cur_tradacc_header into xml;

    Exit when not cur_tradacc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc_data;

   Loop
    Fetch cur_tradacc_data into xml;

    Exit when not cur_tradacc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TradAcc#__a --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#__a"><header>';

   Open cur_tradacc#a_header;

   Loop
    Fetch cur_tradacc#a_header into xml;

    Exit when not cur_tradacc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#a_data;

   Loop
    Fetch cur_tradacc#a_data into xml;

    Exit when not cur_tradacc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';



    -- TradAcc#AvMarkets --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#AvMarkets"><header>';

   Open cur_tradacc#av_header;

   Loop
    Fetch cur_tradacc#av_header into xml;

    Exit when not cur_tradacc#av_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#av_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#av_data;

   Loop
    Fetch cur_tradacc#av_data into xml;

    Exit when not cur_tradacc#av_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#av_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TradAcc#AvMarkets#__a --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#AvMarkets#__a"><header>';

   Open cur_tradacc#av#a_header;

   Loop
    Fetch cur_tradacc#av#a_header into xml;

    Exit when not cur_tradacc#av#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#av#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#av#a_data;

   Loop
    Fetch cur_tradacc#av#a_data into xml;

    Exit when not cur_tradacc#av#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#av#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';



   -- TradAcc#MarketFilters --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#MarketFilters"><header>';

   Open cur_tradacc#mf_header;

   Loop
    Fetch cur_tradacc#mf_header into xml;

    Exit when not cur_tradacc#mf_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mf_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#mf_data;

   Loop
    Fetch cur_tradacc#mf_data into xml;

    Exit when not cur_tradacc#mf_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mf_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TradAcc#MarketFilters#__a --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#MarketFilters#__a"><header>';

   Open cur_tradacc#mf#a_header;

   Loop
    Fetch cur_tradacc#mf#a_header into xml;

    Exit when not cur_tradacc#mf#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mf#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#mf#a_data;

   Loop
    Fetch cur_tradacc#mf#a_data into xml;

    Exit when not cur_tradacc#mf#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mf#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


   -- TradAcc#MktFilterSets --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#MktFilterSets"><header>';

   Open cur_tradacc#mfs_header;

   Loop
    Fetch cur_tradacc#mfs_header into xml;

    Exit when not cur_tradacc#mfs_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mfs_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#mfs_data;

   Loop
    Fetch cur_tradacc#mfs_data into xml;

    Exit when not cur_tradacc#mfs_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mfs_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TradAcc#MktFilterSets#__a --
   xmlObjectString := xmlObjectString || '<table name="TradAcc#MktFilterSets#__a"><header>';

   Open cur_tradacc#mfs#a_header;

   Loop
    Fetch cur_tradacc#mfs#a_header into xml;

    Exit when not cur_tradacc#mfs#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mfs#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc#mfs#a_data;

   Loop
    Fetch cur_tradacc#mfs#a_data into xml;

    Exit when not cur_tradacc#mfs#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc#mfs#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


   -- Trading Account SSI Summary --
   xmlObjectString := xmlObjectString || '<table name="Trading Account SSI Summary"><header>';

   Open cur_tradacc_ssi_sum_header;

   Loop
    Fetch cur_tradacc_ssi_sum_header into xml;

    Exit when not cur_tradacc_ssi_sum_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc_ssi_sum_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tradacc_ssi_sum_data;

   Loop
    Fetch cur_tradacc_ssi_sum_data into xml;

    Exit when not cur_tradacc_ssi_sum_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tradacc_ssi_sum_data;

   xmlObjectString := xmlObjectString || '</data></table>';
   
  -- TA Alert Messages --
 xmlObjectString := xmlObjectString || '<table name="Trading Account Alert Messages"><header>';

 Open cur_ta_alert_header;
  Loop
   Fetch cur_ta_alert_header into xml;
   Exit when not cur_ta_alert_header%FOUND;
  xmlObjectString := xmlObjectString || xml.getStringVal();
  End Loop;
  Close cur_ta_alert_header;
  xmlObjectString := xmlObjectString || '</header><data>';

  Open cur_ta_alert_data;
  Loop
   Fetch cur_ta_alert_data into xml;
   Exit when not cur_ta_alert_data%FOUND;
   xmlObjectString := xmlObjectString || xml.getStringVal();
  End Loop;
  Close cur_ta_alert_data;
  xmlObjectString := xmlObjectString || '</data></table>';
  
 end if;


 select count(0) into coreObjcount from "AssObj#Core" where "oid" = objoid and "ConcreteType" ='Counterparty';

 select count(0) into coreaObjcount from "AssObj#Core#__a" where "oid" = objoid and "ConcreteType" ='Counterparty';

 --Cpty Tables
 if ((coreObjcount > 0) or (coreaObjcount > 0))
 then
    -- Cpty --
   xmlObjectString := xmlObjectString || '<table name="Cpty"><header>';

   Open cur_cpty_header;

   Loop
    Fetch cur_cpty_header into xml;

    Exit when not cur_cpty_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty_data;

   Loop
    Fetch cur_cpty_data into xml;

    Exit when not cur_cpty_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Cpty#__a --
   xmlObjectString := xmlObjectString || '<table name="Cpty#__a"><header>';

   Open cur_cpty#a_header;

   Loop
    Fetch cur_cpty#a_header into xml;

    Exit when not cur_cpty#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty#a_data;

   Loop
    Fetch cur_cpty#a_data into xml;

    Exit when not cur_cpty#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Cpty#CustFilter --
   xmlObjectString := xmlObjectString || '<table name="Cpty#CustFilter"><header>';

   Open cur_cpty#cf_header;

   Loop
    Fetch cur_cpty#cf_header into xml;

    Exit when not cur_cpty#cf_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#cf_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty#cf_data;

   Loop
    Fetch cur_cpty#cf_data into xml;

    Exit when not cur_cpty#cf_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#cf_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Cpty#CustFilter#__a --
   xmlObjectString := xmlObjectString || '<table name="Cpty#CustFilter#__a"><header>';

   Open cur_cpty#cf#a_header;

   Loop
    Fetch cur_cpty#cf#a_header into xml;

    Exit when not cur_cpty#cf#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#cf#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty#cf#a_data;

   Loop
    Fetch cur_cpty#cf#a_data into xml;

    Exit when not cur_cpty#cf#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#cf#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Cpty#MktFilterSet --
   xmlObjectString := xmlObjectString || '<table name="Cpty#MktFilterSet"><header>';

   Open cur_cpty#mfs_header;

   Loop
    Fetch cur_cpty#mfs_header into xml;

    Exit when not cur_cpty#mfs_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#mfs_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty#mfs_data;

   Loop
    Fetch cur_cpty#mfs_data into xml;

    Exit when not cur_cpty#mfs_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#mfs_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Cpty#MktFilterSet#__a --
   xmlObjectString := xmlObjectString || '<table name="Cpty#MktFilterSet#__a"><header>';

   Open cur_cpty#mfs#a_header;

   Loop
    Fetch cur_cpty#mfs#a_header into xml;

    Exit when not cur_cpty#mfs#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#mfs#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_cpty#mfs#a_data;

   Loop
    Fetch cur_cpty#mfs#a_data into xml;

    Exit when not cur_cpty#mfs#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_cpty#mfs#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


 end if;


 select count(0) into coreObjcount from "AssObj#Core" where "oid" = objoid and "ConcreteType" like '%Confirm';

 select count(0) into coreaObjcount from "AssObj#Core#__a" where "oid" = objoid and "ConcreteType" like '%Confirm';

 --Cpty Tables
 if ((coreObjcount > 0) or (coreaObjcount > 0))
 then
    -- TradeConfirm --
   xmlObjectString := xmlObjectString || '<table name="TradeConfirm"><header>';

   Open cur_tc_header;

   Loop
    Fetch cur_tc_header into xml;

    Exit when not cur_tc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tc_data;

   Loop
    Fetch cur_tc_data into xml;

    Exit when not cur_tc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TradeConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="TradeConfirm#__a"><header>';

   Open cur_tc#a_header;

   Loop
    Fetch cur_tc#a_header into xml;

    Exit when not cur_tc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_tc#a_data;

   Loop
    Fetch cur_tc#a_data into xml;

    Exit when not cur_tc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_tc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- EtcConfirm --
   xmlObjectString := xmlObjectString || '<table name="EtcConfirm"><header>';

   Open cur_ec_header;

   Loop
    Fetch cur_ec_header into xml;

    Exit when not cur_ec_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ec_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ec_data;

   Loop
    Fetch cur_ec_data into xml;

    Exit when not cur_ec_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ec_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- EtcConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="EtcConfirm#__a"><header>';

   Open cur_ec#a_header;

   Loop
    Fetch cur_ec#a_header into xml;

    Exit when not cur_ec#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ec#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_ec#a_data;

   Loop
    Fetch cur_ec#a_data into xml;

    Exit when not cur_ec#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_ec#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- FaxConfirm --
   xmlObjectString := xmlObjectString || '<table name="FaxConfirm"><header>';

   Open cur_fc_header;

   Loop
    Fetch cur_fc_header into xml;

    Exit when not cur_fc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_fc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_fc_data;

   Loop
    Fetch cur_fc_data into xml;

    Exit when not cur_fc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_fc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- FaxConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="FaxConfirm#__a"><header>';

   Open cur_fc#a_header;

   Loop
    Fetch cur_fc#a_header into xml;

    Exit when not cur_fc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_fc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_fc#a_data;

   Loop
    Fetch cur_fc#a_data into xml;

    Exit when not cur_fc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_fc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- PhoneConfirm --
   xmlObjectString := xmlObjectString || '<table name="PhoneConfirm"><header>';

   Open cur_phonec_header;

   Loop
    Fetch cur_phonec_header into xml;

    Exit when not cur_phonec_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_phonec_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_phonec_data;

   Loop
    Fetch cur_phonec_data into xml;

    Exit when not cur_phonec_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_phonec_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- PhoneConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="PhoneConfirm#__a"><header>';

   Open cur_phonec#a_header;

   Loop
    Fetch cur_phonec#a_header into xml;

    Exit when not cur_phonec#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_phonec#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_phonec#a_data;

   Loop
    Fetch cur_phonec#a_data into xml;

    Exit when not cur_phonec#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_phonec#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- PostalAddressConfirm --
   xmlObjectString := xmlObjectString || '<table name="PostalAddressConfirm"><header>';

   Open cur_postc_header;

   Loop
    Fetch cur_postc_header into xml;

    Exit when not cur_postc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_postc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_postc_data;

   Loop
    Fetch cur_postc_data into xml;

    Exit when not cur_postc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_postc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- PostalAddressConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="PostalAddressConfirm#__a"><header>';

   Open cur_postc#a_header;

   Loop
    Fetch cur_postc#a_header into xml;

    Exit when not cur_postc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_postc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_postc#a_data;

   Loop
    Fetch cur_postc#a_data into xml;

    Exit when not cur_postc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_postc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TelexConfirm --
   xmlObjectString := xmlObjectString || '<table name="TelexConfirm"><header>';

   Open cur_telexc_header;

   Loop
    Fetch cur_telexc_header into xml;

    Exit when not cur_telexc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_telexc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_telexc_data;

   Loop
    Fetch cur_telexc_data into xml;

    Exit when not cur_telexc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_telexc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- TelexConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="TelexConfirm#__a"><header>';

   Open cur_telexc#a_header;

   Loop
    Fetch cur_telexc#a_header into xml;

    Exit when not cur_telexc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_telexc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_telexc#a_data;

   Loop
    Fetch cur_telexc#a_data into xml;

    Exit when not cur_telexc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_telexc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- SwiftConfirm --
   xmlObjectString := xmlObjectString || '<table name="SwiftConfirm"><header>';

   Open cur_swiftc_header;

   Loop
    Fetch cur_swiftc_header into xml;

    Exit when not cur_swiftc_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_swiftc_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_swiftc_data;

   Loop
    Fetch cur_swiftc_data into xml;

    Exit when not cur_swiftc_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_swiftc_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- SwiftConfirm#__a --
   xmlObjectString := xmlObjectString || '<table name="SwiftConfirm#__a"><header>';

   Open cur_swiftc#a_header;

   Loop
    Fetch cur_swiftc#a_header into xml;

    Exit when not cur_swiftc#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_swiftc#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_swiftc#a_data;

   Loop
    Fetch cur_swiftc#a_data into xml;

    Exit when not cur_swiftc#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_swiftc#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


 end if;


  select count(0) into coreObjcount from "AssObj#Core" where "oid" = objoid and "ConcreteType" = 'Contact';

 select count(0) into coreaObjcount from "AssObj#Core#__a" where "oid" = objoid and "ConcreteType" = 'Contact';

 --Cpty Tables
 if ((coreObjcount > 0) or (coreaObjcount > 0))
 then
    -- Contact --
   xmlObjectString := xmlObjectString || '<table name="Contact"><header>';

   Open cur_contact_header;

   Loop
    Fetch cur_contact_header into xml;

    Exit when not cur_contact_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_contact_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_contact_data;

   Loop
    Fetch cur_contact_data into xml;

    Exit when not cur_contact_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_contact_data;

   xmlObjectString := xmlObjectString || '</data></table>';


    -- Contact#__a --
   xmlObjectString := xmlObjectString || '<table name="Contact#__a"><header>';

   Open cur_contact#a_header;

   Loop
    Fetch cur_contact#a_header into xml;

    Exit when not cur_contact#a_header%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_contact#a_header;

   xmlObjectString := xmlObjectString || '</header><data>';


   Open cur_contact#a_data;

   Loop
    Fetch cur_contact#a_data into xml;

    Exit when not cur_contact#a_data%FOUND;

    xmlObjectString := xmlObjectString || xml.getStringVal();

   End Loop;

   Close cur_contact#a_data;

   xmlObjectString := xmlObjectString || '</data></table>';


 end if;


 xmlObjectString := xmlObjectString || '</report>';


 end;

end;
/

